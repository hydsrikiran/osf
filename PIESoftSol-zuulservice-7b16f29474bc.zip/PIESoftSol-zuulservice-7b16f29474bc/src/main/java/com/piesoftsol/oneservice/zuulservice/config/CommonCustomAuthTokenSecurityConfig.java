package com.piesoftsol.oneservice.zuulservice.config;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.access.ExceptionTranslationFilter;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

import com.piesoftsol.oneservice.zuulservice.annotation.OneServiceJdbc;
import com.piesoftsol.oneservice.zuulservice.model.HeaderAuthModel;
import com.piesoftsol.oneservice.zuulservice.utils.AppLogger;
import com.piesoftsol.oneservice.zuulservice.utils.EnableSecurityCustomAuthTokenBasedCondition;

import static com.piesoftsol.oneservice.zuulservice.config.OneServiceInit._customAuthTokenClass;
import static com.piesoftsol.oneservice.zuulservice.config.OneServiceInit._ValidateHeader;

/**
 * Common class to configure the authentication security for the users accessing
 * the service
 * 
 * <!-- This Class DOES NOT require any modification.-->
 * 
 * @author Kiran
 */

@Conditional(value = {EnableSecurityCustomAuthTokenBasedCondition.class})
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
@Configuration
@EnableWebSecurity
@PropertySource("file:${oneservice.home}/${oneservice.prop}.properties")
@Order(1)
public class CommonCustomAuthTokenSecurityConfig extends WebSecurityConfigurerAdapter {

	private final AppLogger LOGGER = new AppLogger(CommonCustomAuthTokenSecurityConfig.class.getName());
	/**
	 * Spring Actuator paths
	 */
	private static final String[] SPRING_ACTUATOR_PATHS = new String[] { 	"/actuator/health", 
																			"/actuator/metrics", 
																			"/actuator/metrics/*",
																			"/actuator/monitoring",
																			"/swagger-ui.html", "/webjars/**",
																			"/swagger-resources/**", 
																			"/v2/api-docs", "/swagger-ui.html**",
																			"/",
																			"/csrf",
																			"/favicon.ico"};
	
	
	@Value("${oneservice.custom.tokens:#{null}}")
	private Object[] customAuthValues;
	
	@Value("${oneservice.adminuser.name:#{null}}")
	private String adminUserName;
	
	@Value("${oneservice.adminuser.password:#{null}}")
	private String adminPassWord;
	
	@Value("${oneservice.bcrypt.strength:10}")
	private int bcryptStrength;
	
	@OneServiceJdbc
	private JdbcTemplate jdbcTemplate;
	
	/*
	 * To configure authentication based on user level access
	 * 
	 * @param authBuilder parm 1
	 * @throws Exception throws exception
	 */
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder authBuilder) throws Exception {
		authBuilder.userDetailsService(userDetailsService());
        //.inMemoryAuthentication()
            //.withUser(userName).password(passwordEncoder().encode(passWord)).roles("USER");
	}

	@SuppressWarnings("unchecked")
	@Override
	//@Order(SecurityProperties.BASIC_AUTH_ORDER)
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		final String METHOD_NAME = "configure";
		LOGGER.info(METHOD_NAME, "Checking Security : ");
		//PreAuthTokenHeaderFilter filter = new PreAuthTokenHeaderFilter(authHeaderName);
		((AbstractPreAuthenticatedProcessingFilter)_customAuthTokenClass).setAuthenticationManager(new AuthenticationManager() 
        {			
            @Override
            public Authentication authenticate(Authentication authentication) 
                                                throws AuthenticationException 
            {
            	HeaderAuthModel principal = (HeaderAuthModel) authentication.getPrincipal();
            	if(null != _ValidateHeader) {
            		if(null == jdbcTemplate) {
	            		if (!_ValidateHeader.isHeaderValid(principal, customAuthValues))
	                    {
	                        throw new BadCredentialsException("The API key was not found "
	                                                    + "or not the expected value.");
	                    }
            		}else {
            			if (!_ValidateHeader.isHeaderValid(principal, customAuthValues, jdbcTemplate))
	                    {
	                        throw new BadCredentialsException("The API key was not found "
	                                                    + "or not the expected value.");
	                    }
            		}
            	}
                
                authentication.setAuthenticated(true);
                return authentication;
            }            
            
        });
		httpSecurity
		.authorizeRequests().antMatchers(SPRING_ACTUATOR_PATHS).permitAll().and()        
        .addFilter((AbstractPreAuthenticatedProcessingFilter)_customAuthTokenClass)
            .addFilterBefore(new ExceptionTranslationFilter(
                new Http403ForbiddenEntryPoint()), 
            		(Class<? extends AbstractPreAuthenticatedProcessingFilter>) _customAuthTokenClass.getClass()
            )
            .authorizeRequests()
            .antMatchers("/**")
            .authenticated()
                .anyRequest()
                .authenticated();
		
		httpSecurity.csrf().disable();
		httpSecurity.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		httpSecurity.httpBasic();
	}

	/**
	 * Method to get the password bcrypt encoder
	 * 
	 * @return PasswordEncoder return encryption
	 */
	@Bean
	public PasswordEncoder passwordEncoder() {
		final String METHOD_NAME = "passwordEncoder";
		SecureRandom secureRandom = new SecureRandom();
		try {
			SecureRandom.getInstance("SHA1PRNG");
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error(METHOD_NAME, e.getMessage());
		}
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(bcryptStrength, secureRandom);
		
		return encoder;
	}
	
	@Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        /*if(null != userName && !userName.isEmpty() && null != passWord && !passWord.isEmpty()) {
	        manager.createUser(User
	          .withUsername(userName)
	          .password(passwordEncoder().encode(passWord))
	          .roles("USER").build());
        }*/
        if(null != adminUserName && !adminUserName.isEmpty() && null != adminPassWord && !adminPassWord.isEmpty()) {
	        manager.createUser(User
	          .withUsername(adminUserName)
	          .password(passwordEncoder().encode(adminPassWord))
	          .roles("ADMIN").build());
        }
        return manager;
    }
}
