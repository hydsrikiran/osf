package com.piesoftsol.oneservice.zuulservice.model;

import javax.servlet.http.HttpServletRequest;

public class HeaderAuthModel {
	
	private Object[] authHeaderName;
	
	HttpServletRequest request;

	public Object[] getAuthHeaderName() {
		return authHeaderName;
	}

	public void setAuthHeaderName(Object[] authHeaderName) {
		this.authHeaderName = authHeaderName;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	

}
