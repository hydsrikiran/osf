package com.piesoftsol.oneservice.zuulservice.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Indicates spring security enabled using property
 * 
 * EnablePropSecurity requires user and password in application.properties
 * 
 * @author Kiran
 *
 */

@Retention(RUNTIME)
@Target(TYPE)
public @interface EnableCustomAuthTokenSecurity {

}
