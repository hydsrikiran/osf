package com.piesoftsol.oneservice.zuulservice.utils;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.piesoftsol.oneservice.zuulservice.annotation.EnableJdbc;

import static com.piesoftsol.oneservice.zuulservice.config.OneServiceInit.oneServiceBootClass;

/**
 * 
 * @author Kiran
 *
 */

public class JdbcDataBaseCondition implements Condition {
	
	private static final String METHOD = "JdbcDataBaseCondition";
	
	private static final AppLogger LOGGER = new AppLogger(JdbcDataBaseCondition.class.getName());

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		
		if(oneServiceBootClass == null) {
			return false;
		}
		
		try {
			if (oneServiceBootClass.isAnnotationPresent(EnableJdbc.class)) {
				return true;
			}
		}catch(IllegalArgumentException e) 
	    {
	        try {
				throw e;
			} catch (IllegalArgumentException e1) {
				LOGGER.error(METHOD, e1.getMessage());
				System.exit(-100);
			} // rethrowing the exception 
	    }
		
		return false;
	}

}
