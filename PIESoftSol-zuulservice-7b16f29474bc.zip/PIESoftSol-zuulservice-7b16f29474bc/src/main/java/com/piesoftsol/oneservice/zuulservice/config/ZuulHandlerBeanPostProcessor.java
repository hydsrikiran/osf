package com.piesoftsol.oneservice.zuulservice.config;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.cloud.netflix.zuul.web.ZuulHandlerMapping;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import com.piesoftsol.oneservice.zuulservice.utils.DisableCustomInterceptorCondition;

import static com.piesoftsol.oneservice.zuulservice.config.OneServiceInit.osfHandlerInterceptor;

@Conditional(DisableCustomInterceptorCondition.class)
@Configuration
public class ZuulHandlerBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter {

    @Override
    public boolean postProcessAfterInstantiation(final Object bean, final String beanName) throws BeansException {

        if (bean instanceof ZuulHandlerMapping) {

        	ZuulHandlerMapping zuulHandlerMapping = (ZuulHandlerMapping) bean;
            zuulHandlerMapping.setInterceptors(osfHandlerInterceptor);
        }

        return super.postProcessAfterInstantiation(bean, beanName);
    }

}
