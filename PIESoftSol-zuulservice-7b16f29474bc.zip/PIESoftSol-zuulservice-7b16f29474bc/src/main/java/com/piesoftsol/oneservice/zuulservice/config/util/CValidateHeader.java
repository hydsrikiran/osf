package com.piesoftsol.oneservice.zuulservice.config.util;

import org.springframework.jdbc.core.JdbcTemplate;

import com.piesoftsol.oneservice.zuulservice.config.ValidateHeader;
import com.piesoftsol.oneservice.zuulservice.model.HeaderAuthModel;

public class CValidateHeader implements ValidateHeader{

	@Override
	public boolean isHeaderValid(HeaderAuthModel principal, Object[] customAuthValues) {
		for(Object customAuthValue:customAuthValues) {
			String[] customAuthValueSplit = customAuthValue.toString().split(":");
			try {
				if(!principal.getRequest().getHeader(customAuthValueSplit[0]).equals(customAuthValueSplit[1])) {
					return false;
				}
			}catch (NullPointerException e) {
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean isHeaderValid(HeaderAuthModel principal, Object[] customAuthValues, JdbcTemplate jdbcTemplate) {
		for(Object customAuthValue:customAuthValues) {
			String[] customAuthValueSplit = customAuthValue.toString().split(":");
			try {
				if(!principal.getRequest().getHeader(customAuthValueSplit[0]).equals(customAuthValueSplit[1])) {
					return false;
				}
			}catch (NullPointerException e) {
				return false;
			}
		}
		return true;
	}

	
}
