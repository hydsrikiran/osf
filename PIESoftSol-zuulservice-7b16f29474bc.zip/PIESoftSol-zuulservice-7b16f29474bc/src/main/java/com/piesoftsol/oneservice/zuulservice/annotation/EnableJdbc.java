package com.piesoftsol.oneservice.zuulservice.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Indicates JDBC connection required on service start
 * 
 * EnableJdbc needs the proper jdbc connection details and 
 * password with encrypted
 * 
 * @author Kiran
 *
 */
@Retention(RUNTIME)
@Target(TYPE)
public @interface EnableJdbc {

}
