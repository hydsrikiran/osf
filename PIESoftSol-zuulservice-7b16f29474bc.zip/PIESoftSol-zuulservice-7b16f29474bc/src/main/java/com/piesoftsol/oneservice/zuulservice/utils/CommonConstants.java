package com.piesoftsol.oneservice.zuulservice.utils;

public abstract class CommonConstants {
	
	public static final String APP_PID_FILE_WRITER_NAME = "OSFZuul.pid";
	
	public static final String COMMON_PACKAGE_STRUCTURE = "com.piesoftsol.oneservice";
	
	// Bean Qualifier Strings
	public static final String ONESERVICE_JDBC_TEMPLATE = "oneserviceJdbcTemplate";
	public static final String ONESERVICE_DATA_SOURCE = "oneserviceDataSource";

}
