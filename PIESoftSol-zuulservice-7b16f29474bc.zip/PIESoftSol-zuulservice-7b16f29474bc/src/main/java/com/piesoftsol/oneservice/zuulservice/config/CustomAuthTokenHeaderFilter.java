package com.piesoftsol.oneservice.zuulservice.config;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

import com.piesoftsol.oneservice.zuulservice.model.HeaderAuthModel;

public class CustomAuthTokenHeaderFilter extends AbstractPreAuthenticatedProcessingFilter {

	private Object[] authHeaderName;

	public CustomAuthTokenHeaderFilter(Object[] authHeaderName) {
		this.authHeaderName = authHeaderName;
	}

	@Override
	protected HeaderAuthModel getPreAuthenticatedPrincipal(HttpServletRequest request) {
		HeaderAuthModel headerAuthModel = new HeaderAuthModel();
		headerAuthModel.setAuthHeaderName(authHeaderName);
		headerAuthModel.setRequest(request);
		return headerAuthModel;//request.getHeader(authHeaderName);
	}

	@Override
	protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
		return "N/A";
	}
}
