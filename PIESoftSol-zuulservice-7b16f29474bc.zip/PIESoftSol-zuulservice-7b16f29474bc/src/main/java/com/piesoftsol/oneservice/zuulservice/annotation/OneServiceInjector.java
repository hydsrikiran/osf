package com.piesoftsol.oneservice.zuulservice.annotation;

import static com.piesoftsol.oneservice.zuulservice.utils.CommonConstants.COMMON_PACKAGE_STRUCTURE;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * 
 * @author Kiran
 *
 */

@Retention(RUNTIME)
@Target(TYPE)

@SpringBootApplication
@EnableZuulProxy
@EnableDiscoveryClient
@Configuration
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
@Inherited
@ComponentScan({COMMON_PACKAGE_STRUCTURE , "${oneservice.package}"})
@EnableAspectJAutoProxy
public @interface OneServiceInjector {

}
