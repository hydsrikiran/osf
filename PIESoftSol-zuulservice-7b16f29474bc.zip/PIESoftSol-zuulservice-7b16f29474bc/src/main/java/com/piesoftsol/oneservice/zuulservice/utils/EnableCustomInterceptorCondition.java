package com.piesoftsol.oneservice.zuulservice.utils;


import static com.piesoftsol.oneservice.zuulservice.config.OneServiceInit.oneServiceBootClass;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.piesoftsol.oneservice.zuulservice.ZuulServiceApplication;
import com.piesoftsol.oneservice.zuulservice.annotation.CustomInterceptor;

public class EnableCustomInterceptorCondition implements Condition{

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		
		if(oneServiceBootClass == null) {
			return false;
		}
		
		if (ZuulServiceApplication.class.isAnnotationPresent(CustomInterceptor.class)) {
			return true;
		}
		// TODO Auto-generated method stub
		return false;
	}
}
