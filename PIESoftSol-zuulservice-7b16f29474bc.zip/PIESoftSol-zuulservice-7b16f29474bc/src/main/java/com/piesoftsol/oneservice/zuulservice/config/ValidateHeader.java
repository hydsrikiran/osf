package com.piesoftsol.oneservice.zuulservice.config;


import org.springframework.jdbc.core.JdbcTemplate;

import com.piesoftsol.oneservice.zuulservice.model.HeaderAuthModel;
import com.piesoftsol.oneservice.zuulservice.utils.AppLogger;

public interface ValidateHeader {
	
	final AppLogger LOGGER = new AppLogger(ValidateHeader.class.getName());
	
	public boolean isHeaderValid(HeaderAuthModel principal, Object[] customAuthValues);
	
	public boolean isHeaderValid(HeaderAuthModel principal, Object[] customAuthValues, JdbcTemplate jdbcTemplate);
}
