package com.piesoftsol.oneservice.zuulservice;


import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import com.piesoftsol.oneservice.zuulservice.annotation.OneServiceInjector;
import com.piesoftsol.oneservice.zuulservice.config.OneServiceInit;
import com.piesoftsol.oneservice.zuulservice.utils.AppLogger;

@OneServiceInjector
public class ZuulServiceApplication extends SpringBootServletInitializer{	
	
    private static final AppLogger logger = new AppLogger(ZuulServiceApplication.class.getName());
    
    @Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(ZuulServiceApplication.class);
	}

	public static void main(String[] args) throws Exception {
		
		try {
			OneServiceInit.initializeObject(ZuulServiceApplication.class, null, null, null, args);
			logger.info("Zuul Service is up and running...");
		} catch (Exception e) {
			e.printStackTrace();
		}
        
	}
	
}
